# freecodecamp-Quality-Assurance-Certification    
Freecodecamp solution to Quality Assurance Challenges    
    
Glitch App Links:    
- Mocha and Chai: [Glitch App](https://calm-cocoa.glitch.me)   
- Advanced Node and Express app: [Glitch App](https://succulent-crawdad.glitch.me)   
- BCrypt: [Glitch App](https://glitch.com/edit/#!/decisive-sailor)   
- Clean up with Modules: [Glitch App](https://nine-cylinder-1.glitch.me)    
- Social Authnetication: [Glitch App](https://calico-launch-1.glitch.me)    
- Socket IO: [Glitch App](https://painted-stork.glitch.me)    


Project done as part of course:
- Metric-Imperial Converter: [Description](Project-Description/Metric-Imperial-Converter.md): [Glitch App](https://separated-towering-olive.glitch.me/)
- Issue Tracker: [Description](Project-Description/): [Repl App](https://project-american-british-english-translator.mandeep147.repl.co)
- Personal Library: [Description](Project-Description/): [Glitch App]()
